package com.mealbox.entity;

  public class PriceList {
	public static final int VEG_THALI = 100; 
	public static final int NON_VEG_THALI = 130;
	public static final int ALTERNATE = 110;
	public static final int DISHDUO = 125;
	public static final int GST = 5;
	public static final int STANDARD = 20;
	public static final int MINI = 10;
	public static final int DISCOUNT_ONE_MONTH = 400;
	public static final int DISCOUNT_1_WEEK = 100;
	public static final int DELIVERY_CHARGE = 45;
}
